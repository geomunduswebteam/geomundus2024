
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb">

<head>
  <base href="http://www.geomundus.org/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="Geomundus, geomundus, UJI, WWU, UNL" />
  <meta name="description" content="Geomundus" />
  <meta name="generator" content="Joomla! 1.5 - Open Source Content Management" />
  <title>GeoMundus</title>
  <link href="/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="/templates/ja_purity/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <link rel="stylesheet" href="/modules/mod_vvisit_counter/css/mod_vvisit_counter.css" type="text/css" />
  <script type="text/javascript" src="/media/system/js/mootools.js"></script>
  <script type="text/javascript" src="/media/system/js/caption.js"></script>


<link rel="stylesheet" href="http://www.geomundus.org/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="http://www.geomundus.org/templates/system/css/general.css" type="text/css" />
<link rel="stylesheet" href="http://www.geomundus.org/templates/ja_purity/css/template.css" type="text/css" />

<script language="javascript" type="text/javascript" src="http://www.geomundus.org/templates/ja_purity/js/ja.script.js"></script>

<script language="javascript" type="text/javascript">
var rightCollapseDefault='hide';
var excludeModules='35,32,36,37,39';
</script>
<script language="javascript" type="text/javascript" src="http://www.geomundus.org/templates/ja_purity/js/ja.rightcol.js"></script>

<link rel="stylesheet" href="http://www.geomundus.org/templates/ja_purity/css/menu.css" type="text/css" />

<link rel="stylesheet" href="http://www.geomundus.org/templates/ja_purity/css/ja-sosdmenu.css" type="text/css" />
<script language="javascript" type="text/javascript" src="http://www.geomundus.org/templates/ja_purity/js/ja.cssmenu.js"></script>

<link rel="stylesheet" href="http://www.geomundus.org/templates/ja_purity/styles/header/blue/style.css" type="text/css" />
<link rel="stylesheet" href="http://www.geomundus.org/templates/ja_purity/styles/background/lighter/style.css" type="text/css" />
<link rel="stylesheet" href="http://www.geomundus.org/templates/ja_purity/styles/elements/blue/style.css" type="text/css" />

<!--[if IE 7.0]>
<style type="text/css">
.clearfix {display: inline-block;}
</style>
<![endif]-->

<style type="text/css">
#ja-header,#ja-mainnav,#ja-container,#ja-botsl,#ja-footer {width: 950px;margin: 0 auto;}
#ja-wrapper {min-width: 951px;}
</style>

<script type='text/javascript'>
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-33212874-1']);
	_gaq.push(['_trackPageview']);
	(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
</script>
</head>

<body id="bd" class="fs3 Others" >
<a name="Top" id="Top"></a>
<ul class="accessibility">
	<li><a href="#ja-content" title="Skip to content">Skip to content</a></li>
	<li><a href="#ja-mainnav" title="Skip to main navigation">Skip to main navigation</a></li>
	<li><a href="#ja-col1" title="Skip to first column">Skip to first column</a></li>
	<li><a href="#ja-col2" title="Skip to second column">Skip to second column</a></li>
</ul>

<div id="ja-wrapper">

<!-- BEGIN: HEADER -->
<div id="ja-headerwrap">
	<div id="ja-header" class="clearfix" style="background: url(http://www.geomundus.org/templates/ja_purity/images/header/header3.jpg) no-repeat top right;">

	<div class="ja-headermask">&nbsp;</div>

			<h1 class="logo">
			<a href="/index.php" title="Geomundus"><span>Geomundus</span></a>
		</h1>
	
			<ul class="ja-usertools-font">
	      <li><img style="cursor: pointer;" title="Increase font size" src="http://www.geomundus.org/templates/ja_purity/images/user-increase.png" alt="Increase font size" id="ja-tool-increase" onclick="switchFontSize('ja_purity_ja_font','inc'); return false;" /></li>
		  <li><img style="cursor: pointer;" title="Default font size" src="http://www.geomundus.org/templates/ja_purity/images/user-reset.png" alt="Default font size" id="ja-tool-reset" onclick="switchFontSize('ja_purity_ja_font',3); return false;" /></li>
		  <li><img style="cursor: pointer;" title="Decrease font size" src="http://www.geomundus.org/templates/ja_purity/images/user-decrease.png" alt="Decrease font size" id="ja-tool-decrease" onclick="switchFontSize('ja_purity_ja_font','dec'); return false;" /></li>
		</ul>
		<script type="text/javascript">var CurrentFontSize=parseInt('3');</script>
		
			<div id="ja-search">
			<form action="index.php" method="post">
	<div class="search">
		<input name="searchword" id="mod_search_searchword" maxlength="20" alt="Search" class="inputbox" type="text" size="20" value="search..."  onblur="if(this.value=='') this.value='search...';" onfocus="if(this.value=='search...') this.value='';" />	</div>
	<input type="hidden" name="task"   value="search" />
	<input type="hidden" name="option" value="com_search" />
	<input type="hidden" name="Itemid" value="1" />
</form>
		</div>
	
	</div>
</div>
<!-- END: HEADER -->

<!-- BEGIN: MAIN NAVIGATION -->
<div id="ja-mainnavwrap">
	<div id="ja-mainnav" class="clearfix">
	<ul class="menu"><li id="current" class="parent active item1"><a href="http://www.geomundus.org/"><span>Home</span></a><ul><li class="item24"><a href="/index.php/home/registration"><span>Registration</span></a></li><li class="item26"><a href="/index.php/home/contact"><span>Contact</span></a></li></ul></li><li class="parent item2"><a href="/index.php/previous-editions"><span>About GeoMundus</span></a><ul><li class="item50"><a href="/index.php/previous-editions/how-to-participate"><span>How to participate</span></a></li><li class="item41"><a href="/index.php/previous-editions/previous-editions"><span>Previous Editions</span></a></li><li class="item42"><a href="/index.php/previous-editions/promotional-activities"><span>Promotional Activities</span></a></li></ul></li><li class="parent item4"><a href="/index.php/program"><span>Program</span></a><ul><li class="item5"><a href="/index.php/program/sessions"><span>Sessions</span></a></li><li class="item6"><a href="/index.php/program/keynote-speakers"><span>Speakers</span></a></li><li class="item7"><a href="/index.php/program/participants"><span>Participants</span></a></li><li class="item62"><a href="/index.php/program/publications"><span>Publications</span></a></li></ul></li><li class="parent item8"><a href="/index.php/submisions"><span>Submissions</span></a><ul><li class="item43"><a href="/index.php/submisions/guidelines"><span>Guidelines</span></a></li></ul></li><li class="parent item9"><a href="/index.php/location"><span>Location</span></a><ul><li class="item11"><a href="/index.php/location/how-to-get-there"><span>How to get there</span></a></li><li class="item12"><a href="/index.php/location/accomodation"><span>Accomodation</span></a></li></ul></li><li class="parent item32"><a href="/index.php/sponsors"><span>Sponsors</span></a></li><li class="item59"><a href="/index.php/geodroid"><span>GeoDroid</span></a></li><li class="item61"><a href="/index.php/photos/geomundus-2012"><span>Photos 2012</span></a></li></ul>
	</div>
</div>
<!-- END: MAIN NAVIGATION -->

<div id="ja-containerwrap-fl">
<div id="ja-containerwrap2">
	<div id="ja-container">
	<div id="ja-container2" class="clearfix">

		<div id="ja-mainbody-fl" class="clearfix">

		<!-- BEGIN: CONTENT -->
		<div id="ja-contentwrap">
		<div id="ja-content">

			

			
			<table class="blog" cellpadding="0" cellspacing="0">
<tr>
	<td valign="top">
					<div>
		
<div class="contentpaneopen">

<h2 class="contentheading">
		<a href="/index.php/ifgi-photo-competition" class="contentpagetitle">
		IFGI Photo Competition - New Deadline!	</a>
	</h2>




<div class="article-content">
<h2>
	<strong>New deadline! </strong>Participate in the photo competition &quot;Geoinformatics is&nbsp;Everywhere&quot; till <strong>December 14th</strong> and win a gift certificate for 50 Euros&nbsp;from Amazon. More information and submission on&nbsp;<a href="http://ifgi.uni-muenster.de/GIpictures/en/" target="_blank">http://ifgi.uni-muenster.de/GIpictures/en/</a></h2>
<p>
	Do you know the connection between a romanesco broccoli and the fields of mathematics? There is one, similar to the connection between a Geographical Informationsystem and the field of Geoinformatics but it might not be as clear as the link with the broccoli.</p>
<p style="text-align: justify;">
	<br />
	Although Geoinformatics is gaining more and more attention, all the connections this science has to our daily life are most of the times not obvious at first or even second sight. The relationship between a GIS and Geoinformatics is obvious. Geoinformatics is part of a navigation system or geocaching which is also well known by many people. However, only few people know that Geoinformatics is also used for archaeological excavations in Egypt, the monitoring of the discharge of slurry by farmers or the display of waiting times at bus stops. With the &ldquo;Geoinformatics is Everywhere&rdquo; slogan, we want to discover those daily connections and we want YOU to help us. Through a new photo competition we want to find out the impact of Geoinformatics on our daily life.<br />
	<br />
	Upload your picture and a short description on the page below and get a chance to win one of four gift certificates for Amazon for over 50 Euro. The most creative submissions will be nominated by a jury of students and lecturers and become published. The four best submissions will win a price.<br />
	<br />
	Submit now:<br />
	<br />
	<a href="http://ifgi.uni-muenster.de/GIpictures/de/" name="IFGI Photo Competition" target="_blank">http://giv-webteam.uni-muenster.de/GIpictures/de/</a><br />
	<br />
	P.s.: The structure of the romanesco broccoli repeats itself endlessly and und resembles a mathematical pattern known as fractal. ;-)</p></div>



</div>

<span class="article_separator">&nbsp;</span>
		</div>
					<div>
		
<div class="contentpaneopen">

<h2 class="contentheading">
		<a href="/index.php/component/content/article/1-home/1-geomundus-2012" class="contentpagetitle">
		What is GeoMundus?	</a>
	</h2>




<div class="article-content">
<p style="text-align: justify; ">
	GeoMundus is a symposium on different Geoscience disciplines including, but not limited to Geography, Earth and Environmental Studies, Geographic Information Science and Geoinformatics, Agriculture, Ecology and Environment, Disaster Management, and any other area in the broad field of Geoscience. This conference is organized by the students from the consortium of <a href="http://geotech.uni-muenster.de" target="_blank">Erasmus Mundus (EM) International Master's program in Geospatial Technologies</a>. It is a free of charge conference organized by students and for students. The conference will have participants from more than 25 countries, and is also an opportunity to hear from expert speakers from different fields of Geoscience.</p>
<p style="color: red; ">
	<strong><span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); ">EXTENDED SUBMISSION DEADLINES: </span></strong><br style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); " />
	<span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); "> Paper Submission Deadline: <strong>October 15</strong>, 2012 </span><br style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); " />
	<span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); "> Notification of Successful Applicants: </span><span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); ">October 20</span><span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); ">, 2012</span><br style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); " />
	<br style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); " />
	<span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); "> Poster/Map Submission Deadline: <strong>October 15</strong>, 2012</span><br style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); " />
	<span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); "> Notification of Successful Poster/Map Applicants: </span><span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); ">October 20</span><span style="color: #ff0000; font-family: Arial, Helvetica, sans-serif; line-height: 16px; background-color: rgba(0, 0, 0, 0); ">, 2012</span></p></div>



</div>

<span class="article_separator">&nbsp;</span>
		</div>
		</td>
</tr>

<tr>
	<td valign="top">
		<table width="100%"  cellpadding="0" cellspacing="0">
		<tr>
										<td valign="top" width="50%" class="article_column">
				
<div class="contentpaneopen">

<h2 class="contentheading">
		<a href="/index.php/component/content/article/1-home/15-why-participate-in-geomundus-2012" class="contentpagetitle">
		Why participate in GeoMundus 2012?	</a>
	</h2>




<div class="article-content">
<p style="text-align: justify; ">This year, GeoMundus will be held in beautiful <strong>Lisbon</strong>, Portugal on Friday and Saturday, <strong>November 9-10, 2012</strong>.  This conference aims to promote the professional development of Erasmus Mundus Master and other students. It provides students with an opportunity to present their own research, share their ideas and learn about the work of others from a variety of broad but interrelated fields. Furthermore, it creates a forum to meet other students from a diverse range of backgrounds, and share experiences and knowledge.</p>
<p style="margin-bottom: 0cm" align="JUSTIFY">As well as hearing presentations from fellow students, participants at the conference will be involved in a diverse program of invited speakers from academia, business and non-government organizations. We are pleased to announce that our keynote speakers will be Professor Mike Jackson, from the National Geospatial Center, University of Nottingham, UK, Professor Mario Caetano, Associate Researcher of the Instituto Geográfico Português and Invited Professor at ISEGI and Prof. Dr. Martin Raubal, from the Swiss Federal Institute of Technology Zurich.</p>
<p style="margin-bottom: 0cm" align="JUSTIFY">Registration is FREE until Friday, October 26.  After this day, registration will cost twenty euros.</p></div>



</div>

<span class="article_separator">&nbsp;</span>
</td>
														<td valign="top" width="50%" class="article_column column_separator">
				
<div class="contentpaneopen">

<h2 class="contentheading">
		<a href="/index.php/component/content/article/1-home/16-who-should-participate-in-geomundus-2012" class="contentpagetitle">
		Who should participate in GeoMundus 2012?	</a>
	</h2>




<div class="article-content">
<p style="text-align: justify; ">Targeted audiences: (including but not limited to)</p>
<ul>
<li>
<p style="margin-bottom: 0cm" align="JUSTIFY">Students and researchers from International Erasmus Mundus courses in geography, earth and environmental studies</p>
</li>
<li>
<p style="margin-bottom: 0cm" align="JUSTIFY">Local and international students in the scientific community of geography, earth and environmental studies</p>
</li>
<li>
<p style="margin-bottom: 0cm" align="JUSTIFY">Related local and international NGOs, UN, academic and business communities</p>
</li>
<li>
<p style="margin-bottom: 0cm" align="JUSTIFY">General public</p>
</li>
</ul>
<p style="margin-bottom: 0cm" align="JUSTIFY"> </p></div>



</div>

<span class="article_separator">&nbsp;</span>
</td>
								
		</tr>
		</table>
	</td>
</tr>

</table>


			
		</div>
		</div>
		<!-- END: CONTENT -->

		
		</div>

				<!-- BEGIN: RIGHT COLUMN -->
		<div id="ja-col2">
					<div class="jamod module" id="Mod44">
			<div>
				<div>
					<div>
												<div class="jamod-content">
<script type="text/javascript" src="http://apis.google.com/js/plusone.js">
{lang: 'en-US'}
</script>
<div class="" style="color:#999;margin-bottom:3px;font-size:11px; float:left; margin:5px; width:98px;">
<g:plusone size="standard" href="/" count="1">
</g:plusone><br />
</div>










</div>
					</div>
				</div>
			</div>
		</div>
			<div class="jamod module" id="Mod35">
			<div>
				<div>
					<div>
												<div class="jamod-content"><div id="fb-root"></div><script language="javascript" type="text/javascript">(function(d, s, id) {  var js, fjs = d.getElementsByTagName(s)[0];  if (d.getElementById(id)) {return;}  js = d.createElement(s); js.id = id;  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";  fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script><script language="javascript" type="text/javascript">//<![CDATA[ 
																						   document.write('<div class="fb-like-box" data-href="http://www.facebook.com/pages/GeoMundus/187907541256479" data-width="170" data-height="60" data-colorscheme="light" data-show-faces="true" data-border-color="#000000" data-stream="false" data-force-wall="false" data-header="true"></div> '); 
																						   //]]>
			</script> </div>
					</div>
				</div>
			</div>
		</div>
			<div class="jamod module" id="Mod37">
			<div>
				<div>
					<div>
												<div class="jamod-content"><script type="text/javascript" src="http://widgets.twimg.com/j/2/widget.js"></script><script type="text/javascript">new TWTR.Widget({version: 2,type: 'profile',rpp: 4,interval: 20000,  width: 'auto',height: 180,theme: {shell: {background: '#1374a5',color: '#000000'},tweets: {background: '#FFFFFF',color: '#000000',links: '#00A0BC'}},features: {scrollbar: true,loop: false,live: true,hashtags: false,timestamp: false,avatars: false,behavior: 'all'}}).render().setUser('@geomundus').start();</script></div>
					</div>
				</div>
			</div>
		</div>
			<div class="jamod module" id="Mod18">
			<div>
				<div>
					<div>
																		<h3 class="show"><span>Login</span></h3>
												<div class="jamod-content"><form action="index.php" method="post" name="form-login" id="form-login" >
		<fieldset class="input">
	<p id="form-login-username">
		<label for="username">
			Username<br />
			<input name="username" id="username" type="text" class="inputbox" alt="username" size="18" />
		</label>
	</p>
	<p id="form-login-password">
		<label for="passwd">
			Password<br />
			<input type="password" name="passwd" id="passwd" class="inputbox" size="18" alt="password" />
		</label>
	</p>
		<p id="form-login-remember">
		<label for="remember">
			Remember Me			<input type="checkbox" name="remember" id="remember" value="yes" alt="Remember Me" />
		</label>
	</p>
		<input type="submit" name="Submit" class="button" value="Login" />
	</fieldset>
	<ul>
		<li>
			<a href="/index.php/component/user/reset">
			Forgot your password?			</a>
		</li>
		<li>
			<a href="/index.php/component/user/remind">
			Forgot your username?			</a>
		</li>
			</ul>
	
	<input type="hidden" name="option" value="com_user" />
	<input type="hidden" name="task" value="login" />
	<input type="hidden" name="return" value="L2luZGV4LnBocA==" />
	<input type="hidden" name="add13cf80e8387115a0246611bf27f2a" value="1" /></form>
</div>
					</div>
				</div>
			</div>
		</div>
			<div class="jamod module" id="Mod34">
			<div>
				<div>
					<div>
												<div class="jamod-content"><div class="advs bannergroup">

<div class="banneritem"><a href="/index.php/component/banners/click/1" target="_blank"><img src="http://www.geomundus.org/images/banners/EMA-short-e1315703437195.jpg" alt="Banner" /></a>	</div>
<div class="banneritem"><a href="/index.php/component/banners/click/2" target="_blank"><img src="http://www.geomundus.org/images/banners/ifgilogo.gif" alt="Banner" /></a>	</div>
<div class="banneritem"><a href="/index.php/component/banners/click/3" target="_blank"><img src="http://www.geomundus.org/images/banners/s-logo-isegi-unl.jpg" alt="Banner" /></a>	</div>
<div class="banneritem"><a href="/index.php/component/banners/click/4" target="_blank"><img src="http://www.geomundus.org/images/banners/uji-small.jpg" alt="Banner" /></a>	</div>
<div class="banneritem"><a href="/index.php/component/banners/click/5" target="_blank"><img src="http://www.geomundus.org/images/banners/wwu_logo-e1309703807640.png" alt="Banner" /></a>	</div>

</div>
</div>
					</div>
				</div>
			</div>
		</div>
			<div class="jamod module" id="Mod46">
			<div>
				<div>
					<div>
												<div class="jamod-content"><div class="advs bannergroup">

<div class="banneritem"><a href="/index.php/component/banners/click/7" target="_blank"><img src="http://www.geomundus.org/images/banners/logo_innovatig_170x96.png" alt="Banner" /></a>	</div>

</div>
</div>
					</div>
				</div>
			</div>
		</div>
			<div class="jamod module" id="Mod43">
			<div>
				<div>
					<div>
												<div class="jamod-content"><script src="http://mortal.bumpin.com/files/u_24890.js" type="text/javascript" ></script>
		<div id="ipw-live_feed">
		  <div id="bsb-app-live_feed" class="b-sb-ipw"></div>
		  <div class="bsb-link-div" style="width: 100%; font-size: 8px; text-align: right; left: -5px; top: 0px; position: relative; background: transparent; direction: ltr; background-color: transparent; font-family : arial,tahoma,'lucida grande',verdana,sans-serif; opacity: 1; ">Get this
		  <a  class="bsb-link-text" href="http://www.ticketmy.com/widgets/live_feed.php" style="color:#2d2d2d; direction: ltr; font-size :10px;  background-color: transparent; background: transparent;" target="_blank"> Real Time Visitors </a> Widget
		</div>
		</div></div>
					</div>
				</div>
			</div>
		</div>
	
		</div><br />
		<!-- END: RIGHT COLUMN -->
		
	</div>
	</div>
</div>
</div>

<!-- BEGIN: BOTTOM SPOTLIGHT -->
<div id="ja-botslwrap">
	<div id="ja-botsl" class="clearfix">

	  	  <div class="ja-box-left" style="width: 22%;">
					<div class="moduletable">
					<div class="advs bannergroup">

<div class="banneritem"><a href="/index.php/component/banners/click/6" target="_blank"><img src="http://www.geomundus.org/images/banners/logob1.png" alt="Banner" /></a>	</div>

</div>
		</div>
	
	  </div>
	  
	  	  <div class="ja-box-center" style="width: 38.5%;">
					<div class="moduletable">
					



<table class="contentpaneopen">
	<tr>
		<td valign="top" ><ul>
	<li>
		You can already download the published papers of GeoMundus 2012 <a href="http://geomundus.org/index.php/program/publications" target="_self">here</a>.</li>
</ul></td>
	</tr>
	<tr>
        <td valign="top" >

       		</td>
     </tr>
</table>
		<span class="article_separator">&nbsp;</span>
 	


<table class="contentpaneopen">
	<tr>
		<td valign="top" ><ul>
	<li>
		For any kind of communication regarding GeoMundus 2012, please feel free to <a href="http://geomundus.org/index.php?option=com_contact&amp;view=contact&amp;id=1&amp;Itemid=26">contact</a> us.</li>
</ul></td>
	</tr>
	<tr>
        <td valign="top" >

       		</td>
     </tr>
</table>
		<span class="article_separator">&nbsp;</span>
 	


<table class="contentpaneopen">
	<tr>
		<td valign="top" ><ul>
	<li>
		Don't forget to visit our new <a href="http://geomundus.org/index.php/videos">Video</a> and <a href="http://geomundus.org/index.php/photos/lisbon">Photo</a> galleries!</li>
</ul></td>
	</tr>
	<tr>
        <td valign="top" >

       		</td>
     </tr>
</table>
		</div>
	
	  </div>
	  
	  
	  	  <div class="ja-box-right" style="width: 38.5%;">
					<div class="moduletable">
					<!-- Vinaora Visitors Counter for Joomla! --><div id="vvisit_counter"><div><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/digit_counter/default/0.png" alt="mod_vvisit_counter" title="Vinaora Visitors Counter 2.0" /><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/digit_counter/default/1.png" alt="mod_vvisit_counter" title="Vinaora Visitors Counter 2.0" /><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/digit_counter/default/1.png" alt="mod_vvisit_counter" title="Vinaora Visitors Counter 2.0" /><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/digit_counter/default/3.png" alt="mod_vvisit_counter" title="Vinaora Visitors Counter 2.0" /><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/digit_counter/default/2.png" alt="mod_vvisit_counter" title="Vinaora Visitors Counter 2.0" /><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/digit_counter/default/2.png" alt="mod_vvisit_counter" title="Vinaora Visitors Counter 2.0" /><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/digit_counter/default/2.png" alt="mod_vvisit_counter" title="Vinaora Visitors Counter 2.0" /></div><div><table cellpadding="0" cellspacing="0" style="width: 90%;"><tbody><tr align="left"><td><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/stats/default/vtoday.png" alt="mod_vvisit_counter" title="2013-06-05" /></td><td>Today</td><td align="right">118</td></tr><tr align="left"><td><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/stats/default/vweek.png" alt="mod_vvisit_counter" title="2013-06-03 -&gt; 2013-06-05" /></td><td>This week</td><td align="right">705</td></tr><tr align="left"><td><img src="http://www.geomundus.org/modules/mod_vvisit_counter/images/stats/default/vall.png" alt="mod_vvisit_counter" title="Since: 2012-07-16" /></td><td>All days</td><td align="right">113222</td></tr></tbody></table></div><div><a href="http://vinaora.com" target="_self" title="Vinaora Visitors Counter 2.0 for Joomla!">Visitors Counter</a></div></div>		</div>
	
	  </div>
	  
	</div>
</div>
<!-- END: BOTTOM SPOTLIGHT -->

<!-- BEGIN: FOOTER -->
<div id="ja-footerwrap">
<div id="ja-footer" class="clearfix">

	<div id="ja-footnav">
		
	</div>

	<div class="copyright">
		 We have&nbsp;5 guests&nbsp;online<div>Copyright &#169; 2013 Geomundus. All Rights Reserved.</div>
<div><a href="http://www.joomla.org">Joomla!</a> is Free Software released under the <a href="http://www.gnu.org/licenses/gpl-2.0.html">GNU/GPL License.</a></div>
	</div>

	<div class="ja-cert">
		<a href="/index.php?format=feed&amp;type=rss">
	<img src="/images/M_images/livemarks.png" alt="feed-image"  /> <span>Feed Entries</span></a>
    <a href="http://jigsaw.w3.org/css-validator/check/referer" target="_blank" title="Our site is valid CSS" style="text-decoration: none;">
		<img src="http://www.geomundus.org/templates/ja_purity/images/but-css.gif" border="none" alt="Our site is valid CSS" />
		</a>
		<a href="http://validator.w3.org/check/referer" target="_blank" title="Our site is valid XHTML 1.0 Transitional" style="text-decoration: none;">
		<img src="http://www.geomundus.org/templates/ja_purity/images/but-xhtml10.gif" border="none" alt="Our site is valid XHTML 1.0 Transitional" />
		</a>
	</div>

	<br />
</div>
</div>
<!-- END: FOOTER -->

</div>



</body>

</html>
